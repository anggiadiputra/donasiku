import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { crypto } from 'https://deno.land/std@0.177.0/crypto/mod.ts'

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// MD5 hash function for Duitku signature
async function md5(str: string): Promise<string> {
    const msgUint8 = new TextEncoder().encode(str)
    const hashBuffer = await crypto.subtle.digest('MD5', msgUint8)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('')
}

serve(async (req) => {
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders })
    }

    try {
        console.log('⏰ Cron Check Transactions - Starting...')

        const DUITKU_MERCHANT_CODE = Deno.env.get('DUITKU_MERCHANT_CODE') || ''
        const DUITKU_API_KEY = Deno.env.get('DUITKU_API_KEY') || ''
        const DUITKU_SANDBOX = Deno.env.get('DUITKU_SANDBOX') === 'true'
        const DUITKU_BASE_URL = DUITKU_SANDBOX
            ? 'https://sandbox.duitku.com/webapi/api/merchant'
            : 'https://passport.duitku.com/webapi/api/merchant'

        const supabase = createClient(
            Deno.env.get('SUPABASE_URL') ?? '',
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
        )

        // 1. Fetch Expired Pending Transactions
        // Logic: status='pending' AND expiry_time < NOW()
        const now = new Date().toISOString();
        const { data: expiredTransactions, error: fetchError } = await supabase
            .from('transactions')
            .select('merchant_order_id, id, campaign_id, customer_name, customer_phone, amount')
            .eq('status', 'pending')
            .lt('expiry_time', now)
            .limit(50); // Process in batches

        if (fetchError) {
            throw fetchError;
        }

        console.log(`📦 Found ${expiredTransactions?.length || 0} expired pending transactions.`);

        if (!expiredTransactions || expiredTransactions.length === 0) {
            return new Response(JSON.stringify({ message: 'No expired transactions found' }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            })
        }

        const results = [];

        for (const transaction of expiredTransactions) {
            const merchantOrderId = transaction.merchant_order_id;
            console.log(`🔍 Checking Status for: ${merchantOrderId}`);

            // Calculate signature
            const signatureString = `${DUITKU_MERCHANT_CODE}${merchantOrderId}${DUITKU_API_KEY}`
            const signature = await md5(signatureString)

            // Call Duitku
            const duitkuRes = await fetch(`${DUITKU_BASE_URL}/transactionStatus`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    merchantCode: DUITKU_MERCHANT_CODE,
                    merchantOrderId: merchantOrderId,
                    signature: signature,
                }),
            });

            const duitkuData = await duitkuRes.json();

            // Map Status
            let status = 'pending';
            if (duitkuData.statusCode === '00') status = 'success';
            else if (duitkuData.statusCode === '02') status = 'failed';
            else if (duitkuData.statusCode === '01') status = 'pending'; // Still pending in Duitku?

            // Note: If Duitku says "01" (Pending) but we know it's expired locally, 
            // the user requested "Failed based on API". 
            // Some gateways keep it pending until they close it. 
            // If we strictly follow "Based on API", we keep it Pending?
            // BUT usually Duitku will return "Expired" or "Failed" if time passed.
            // If result is "Transaction Not Found", usually means Failed/Expired.

            console.log(`🎯 Duitku Status for ${merchantOrderId}: ${duitkuData.statusCode} -> ${status}`);

            if (status !== 'pending') {
                // Update DB
                const { error: updateError } = await supabase
                    .from('transactions')
                    .update({
                        status: status,
                        result_code: duitkuData.statusCode,
                        status_message: duitkuData.statusMessage,
                        updated_at: new Date().toISOString(),
                    })
                    .eq('merchant_order_id', merchantOrderId);

                if (updateError) console.error(`❌ Update Error ${merchantOrderId}:`, updateError);

                // If Success (Lazy late payment?), Update Campaign & Send WA
                if (status === 'success') {
                    // Update Campaign
                    if (transaction.campaign_id) {
                        // Fetch current
                        const { data: camp } = await supabase.from('campaigns').select('current_amount, title').eq('id', transaction.campaign_id).single();
                        if (camp) {
                            await supabase.from('campaigns').update({
                                current_amount: (camp.current_amount || 0) + transaction.amount
                            }).eq('id', transaction.campaign_id);
                        }

                        // Send WA (Simplified reuse)
                        // TODO: Extract WA logic if dry needed. For now, duplication is robust.
                        const FONNTE_TOKEN = Deno.env.get('FONNTE_TOKEN');
                        if (FONNTE_TOKEN && transaction.customer_phone) {
                            const { data: settings } = await supabase.from('app_settings').select('whatsapp_success_template').single();
                            let msg = settings?.whatsapp_success_template || 'Terima kasih {name}, donasi {amount} untuk {campaign} diterima.';
                            msg = msg
                                .replace(/{name}/g, transaction.customer_name || 'Hamba Allah')
                                .replace(/{amount}/g, new Intl.NumberFormat('id-ID').format(transaction.amount))
                                .replace(/{campaign}/g, camp?.title || 'Campaign');

                            const form = new FormData();
                            form.append('target', transaction.customer_phone);
                            form.append('message', msg);

                            await fetch('https://api.fonnte.com/send', {
                                method: 'POST',
                                headers: { 'Authorization': FONNTE_TOKEN },
                                body: form
                            });
                        }
                    }
                }

                results.push({ merchantOrderId, status, updated: true });
            } else {
                results.push({ merchantOrderId, status, updated: false, reason: 'Still Pending in API' });
            }
        }

        return new Response(JSON.stringify({ processed: results.length, results }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })

    } catch (error) {
        console.error('💥 Cron Error:', error)
        return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: corsHeaders })
    }
})
